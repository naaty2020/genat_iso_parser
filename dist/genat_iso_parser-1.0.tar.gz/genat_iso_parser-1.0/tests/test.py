from iso_parser.src.genat_iso_parser.Iso import IsoStream

if __name__ == '__main__':
    iso = IsoStream()
    iso.stream()